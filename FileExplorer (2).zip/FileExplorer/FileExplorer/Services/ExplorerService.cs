﻿using FileExplorer.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileExplorer.Services
{
    public class ExplorerService : IExplorerService
    {
        public int GetRowsNumber(string dirPath) 
        {
            string[] files = Directory.GetFiles(dirPath);
            string[] dirs = Directory.GetDirectories(dirPath);

            return (int)Math.Floor((decimal)(files.Length + dirs.Length) / 5) + 1;
        }
        public string[] GetFileNames(string dirPath) {
            return Directory.GetFiles(dirPath);
        }
        public string[] GetDirNames(string dirPath)
        {
            return Directory.GetDirectories(dirPath);
        }
    }
}
