﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileExplorer.Interfaces
{
    public interface IExplorerService
    {
        public int GetRowsNumber(string dirPath);
        public string[] GetFileNames(string dirPath);
        public string[] GetDirNames(string dirPath);
    }
    
}
