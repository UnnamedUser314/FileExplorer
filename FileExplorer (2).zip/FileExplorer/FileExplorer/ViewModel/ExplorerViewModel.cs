﻿using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace FileExplorer.ViewModel
{
    public partial class ExplorerViewModel : ViewModelBase
    {
        string dirpath = @"C:\study\FP\DI\FileExplorer\FileExplorer\File";
        Services.ExplorerService fileService = new Services.ExplorerService();

        private UIElement _griddi;
        public UIElement Griddi
        {
            get => _griddi;
            set
            {
                _griddi = value;
                OnPropertyChanged(nameof(Griddi));
            }
        }

        

        public ExplorerViewModel() {
            GenerateGrid();
            
        }
        public void GenerateGrid()
        {
            
            //int rowsNum = fileService.GetRowsNumber("/File");

            Grid g = new Grid();     
            ColumnDefinition colDef1 = new ColumnDefinition();
            

            g.ColumnDefinitions.Add(colDef1);


            string[] dirNames = fileService.GetDirNames(dirpath);
            string[] fileNames = fileService.GetFileNames(dirpath);

            int rowIndex = 0;
            for(int i = 0; i < dirNames.Length; i++)
            {
                string[] textFull = dirNames[i].Split("\\");
                string text = textFull[textFull.Length-1];

                RowDefinition gRowDefinition = new RowDefinition();
                gRowDefinition.Height =GridLength.Auto;
                g.RowDefinitions.Add(gRowDefinition);

                StackPanel stackPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(5)
                };

                
                Image icon = new Image
                {
                    Source = new BitmapImage(new Uri("C:\\study\\FP\\DI\\FileExplorer\\FileExplorer\\IMG\\dir.png")),
                    Width = 16,
                    Height = 16,
                    Margin = new Thickness(0, 0, 5, 0)
                };

                TextBlock dirText = new TextBlock               
                {
                    Text =text,
                    
           
                };

                stackPanel.Children.Add(icon);
                stackPanel.Children.Add(dirText);

                Border border = new Border
                {
                    Background = new SolidColorBrush(Color.FromRgb(230, 230, 250)), 
                    CornerRadius = new CornerRadius(8), 
                    BorderBrush = new SolidColorBrush(Color.FromRgb(200, 200, 220)),
                    BorderThickness = new Thickness(1),
                    Padding = new Thickness(5),
                    Margin = new Thickness(5),
                    Child = stackPanel
                };

                Grid.SetRow(border, rowIndex++);
                g.Children.Add(border);
            }
            for (int i = 0; i < fileNames.Length; i++)
            {
                string[] textFull = fileNames[i].Split("\\");
                string text = textFull[textFull.Length - 1];

                RowDefinition gRowDefinition = new RowDefinition();
                gRowDefinition.Height = GridLength.Auto;
                g.RowDefinitions.Add(gRowDefinition);

                StackPanel stackPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(5)
                };

                
                Image icon = new Image
                {
                    Source = new BitmapImage(new Uri("C:\\study\\FP\\DI\\FileExplorer\\FileExplorer\\IMG\\file.png")),
                    Width = 16,
                    Height = 16,
                    Margin = new Thickness(0, 0, 5, 0)
                };

                TextBlock dirText = new TextBlock
                {
                    Text = text,
                    Margin = new Thickness(0, 2, 0, 0)

                };

                stackPanel.Children.Add(icon);
                stackPanel.Children.Add(dirText);

                Border border = new Border
                {
                    Background = new SolidColorBrush(Color.FromRgb(230, 230, 250)), 
                    CornerRadius = new CornerRadius(8), 
                    BorderBrush = new SolidColorBrush(Color.FromRgb(200, 200, 220)),
                    BorderThickness = new Thickness(1),
                    Padding = new Thickness(5),
                    Margin = new Thickness(5),
                    Child = stackPanel
                };


                Grid.SetRow(border, rowIndex++);
                g.Children.Add(border);
            }
            Griddi = g;
            
        }
        
        [RelayCommand]
        private void CreateFile(object parameter)
        {
            string fileName = PromptForName("Introduce el nombre del SukoChero:");
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                fileName+=".txt";
                string filePath = Path.Combine(dirpath, fileName);
                File.Create(filePath).Close();
                RefreshFileGrid();
            }
        }
        [RelayCommand]
        private void CreateFolder(object parameter)
        {
            string folderName = PromptForName("Introduce nombre de la SukaPeta:");
            if (!string.IsNullOrWhiteSpace(folderName))
            {
                string folderPath = Path.Combine(dirpath, folderName);
                Directory.CreateDirectory(folderPath);
                RefreshFileGrid();
                
            }
        }

        private string PromptForName(string message)
        {
            return Microsoft.VisualBasic.Interaction.InputBox(message, "Create New Item", "NewItem");
        }

        private void RefreshFileGrid()
        {
           
            GenerateGrid();
            
        }
        
        public override Task LoadAsync()
        {
            return base.LoadAsync();
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        
    }

    
}
