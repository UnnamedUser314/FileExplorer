﻿using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileExplorer.ViewModel
{
    public partial class MainViewModel : ViewModelBase
    {
        private ViewModelBase? _selectedViewModel;
        //private ExplorerViewModel _explorerViewModel;
        //private InfoViewModel _infoViewModel;

        public MainViewModel(ExplorerViewModel explorerViewModel, InfoViewModel infoViewModel)
        {
            SelectedViewModel = null;
            ExplorerViewModel = explorerViewModel;
            InfoViewModel = infoViewModel;
        }

        public ViewModelBase? SelectedViewModel
        {
            get => _selectedViewModel;
            set
            {
                SetProperty(ref _selectedViewModel, value);
            }
        }
        public ExplorerViewModel ExplorerViewModel { get;  }
        public InfoViewModel InfoViewModel { get;  }


        public async override Task LoadAsync()
        {
            if (SelectedViewModel is not null)
            {
                await SelectedViewModel.LoadAsync();
            }
        }

        [RelayCommand]
        private async void SelectViewModel(object? parameter)
        {
            SelectedViewModel = parameter as ViewModelBase;
            await LoadAsync();
        }
    }
}
